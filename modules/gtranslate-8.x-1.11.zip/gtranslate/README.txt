INTRODUCTION
------------

GTranslate uses Google power to translate your web page.
With 103 available languages your site will be available to more than 99% of internet users.

-- INSTALLATION --

* Install as you would normally install a contributed Drupal module. See:
   https://drupal.org/documentation/install/modules-themes/modules-8
   for further information.

CONFIGURATION
-------------

Once the module has been installed, navigate to
/admin/config/user-interface/gtranslate
(Configuration > USER INTERFACE > GTranslate through the administration panel)
to configure the GTranslate.
